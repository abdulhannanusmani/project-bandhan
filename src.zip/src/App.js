// import React from 'react';
// import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
// import Home from './components/Home';
// import ServiceProvider from './components/ServiceProvider';
// import YourBookings from './components/YourBookings';
// import Venues from './components/Venues';
// import ContactUs from './components/ContactUs';
// import './App.css';

// function App() {
//   return (
//     <Router>
//       <div className="App">
//         <header>
//           <nav>
//             <ul>
//               <li><Link to="/">Home</Link></li>
//               <li><Link to="/service-provider">Service Provider</Link></li>
//               <li><Link to="/your-bookings">Your Bookings</Link></li>
//               <li><Link to="/venues">Venues</Link></li>
//               <li><Link to="/contact-us">Contact Us</Link></li>
//             </ul>
//           </nav>
//         </header>

//         <Routes>
//           <Route path="/" element={<Home />} />
//           <Route path="/service-provider" element={<ServiceProvider />} />
//           <Route path="/your-bookings" element={<YourBookings />} />
//           <Route path="/venues" element={<Venues />} />
//           <Route path="/contact-us" element={<ContactUs />} />
//         </Routes>

//         <footer>
//           <p>© 2024 Bandhan.pk - Book Venues Easily</p>
//         </footer>
//       </div>
//     </Router>
//   );
// }

// export default App;



import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Home from './components/Home';
import ServiceProvider from './components/ServiceProvider';
import YourBookings from './components/YourBookings';
import Venues from './components/Venues';
import ContactUs from './components/ContactUs';
import './App.css';




function App() {
  return (
    <Router>
      <div className="App">
        <header className="header">
          <div className="logo">
            <img src="/whitelogo.png" alt="Logo" />
          </div>
          <nav className="nav-center">
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/service-provider">Service Provider</Link></li>
              <li><Link to="/your-bookings">Your Bookings</Link></li>
              <li><Link to="/venues">Venues</Link></li>
              <li><Link to="/contact-us">Contact Us</Link></li>
            </ul>
          </nav>
          <div className="auth-buttons">
            <button className="register-btn">Register</button>
            <button className="login-btn">Login</button>
          </div>
        </header>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/service-provider" element={<ServiceProvider />} />
          <Route path="/your-bookings" element={<YourBookings />} />
          <Route path="/venues" element={<Venues />} />
          <Route path="/contact-us" element={<ContactUs />} />
        </Routes>

        <footer className="footer">
          <div className="footer-left">
            <p>1234 Main Street, City, Country</p>
          </div>
          <div className="footer-center">
            <img src="/whitelogo.png" alt="Logo" />
            <p>Booking made easy. Your one-stop solution for venue reservations.</p>
          </div>
          <div className="footer-right">
            <p>Email: info@example.com</p>
            <p>Phone: +123 456 7890</p>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;
