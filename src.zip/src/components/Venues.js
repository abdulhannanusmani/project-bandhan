import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Venues = () => {
  const [venues, setVenues] = useState([]);

  useEffect(() => {
    // Fetch venues from the backend
    axios.get('/api/venues').then((response) => {
      setVenues(response.data);
    });
  }, []);

  return (
    <div>
      <h2>Available Venues</h2>
      <ul>
        {venues.map((venue) => (
          <li key={venue.id}>
            <h3>{venue.name}</h3>
            <p>{venue.description}</p>
            <p>Price: {venue.price}</p>
            <button>Book Now</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Venues;
