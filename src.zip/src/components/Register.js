import React, { useState } from 'react';
import axios from 'axios';

const Register = () => {
  const [userType, setUserType] = useState('user');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [cnic, setCnic] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { userType, email, password, phone, cnic };
    axios.post('/api/register', data).then((response) => {
      if (response.data.success) {
        window.location = '/login';
      } else {
        alert('Error in registration');
      }
    });
  };

  return (
    <div>
      <h2>Register</h2>
      <form onSubmit={handleSubmit}>
        <select value={userType} onChange={(e) => setUserType(e.target.value)}>
          <option value="user">User</option>
          <option value="venue_owner">Venue Owner</option>
        </select>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input
          type="text"
          placeholder="Phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        {userType === 'venue_owner' && (
          <input
            type="text"
            placeholder="CNIC"
            value={cnic}
            onChange={(e) => setCnic(e.target.value)}
          />
        )}
        <button type="submit">Register</button>
      </form>
    </div>
  );
}

export default Register;
