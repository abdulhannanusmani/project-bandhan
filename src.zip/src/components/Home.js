import React, { useState } from 'react';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import './Home.css'; // CSS for styling

const Home = () => {
  const [selectedDate, setSelectedDate] = useState(null);

  const locations = ["North Nazimabad ", "Gulistan E Jauhar", "University Road", "Sakhi Hasan", "Ayesha Manzil"];
  const prices = ["50,000 - 110,000 PKR", "120,000 - 160,000 PKR", "170,000 - 220,000 PKR", "230,000 - 350,000 PKR", "360,000 - Above"];

  return (
    <div className="home">
      <div className="slider-item">
        <img src="/hall1.jpg" alt="Slider" />
        <div className="overlay">
          <h1>Wedding Venues Near You</h1>

          <div className="dropdowns">
            {/* Location Dropdown */}
            <select className="dropdown" defaultValue="Location">
              <option disabled>Location</option>
              {locations.map((location, index) => (
                <option key={index} value={location}>{location}</option>
              ))}
            </select>

            {/* Date Dropdown (Calendar Picker) */}
            <DatePicker 
              className="dropdown"
              selected={selectedDate}
              onChange={(date) => setSelectedDate(date)}
              placeholderText="Select Date"
            />

            {/* Prices Dropdown */}
            <select className="dropdown" defaultValue="Price Range">
              <option disabled>Price Range</option>
              {prices.map((price, index) => (
                <option key={index} value={price}>{price}</option>
              ))}
            </select>
          </div>
          <button className="search-button">SEARCH</button>

        </div>
      </div>
    

      {/* New Section Below the Slider */}
      <div className="service-section">
        <h2 className="service-heading">Our Services</h2>
        <div className="service-container">
          <div className="service-box">
            <img src="/hall2.jpg" alt="Service 1" className="service-image" />
            <div className="service-details">
              <h3 className="service-category">Wedding Venues</h3>
              <p className="service-description">100+ Registered Venues.</p>
              <img src="/small-image-1.jpg" alt="Catering Icon" className="small-image" />
            </div>
          </div>
          <div className="service-box">
            <img src="/photography.jpg" alt="Service 2" className="service-image" />
            <div className="service-details">
              <h3 className="service-category">Photographers</h3>
              <p className="service-description">20+ Registered Photographers.</p>
              <img src="/small-image-2.jpg" alt="Decoration Icon" className="small-image" />
            </div>
          </div>
          <div className="service-box">
            <img src="/catering.jpg" alt="Service 3" className="service-image" />
            <div className="service-details">
              <h3 className="service-category">Caterers</h3>
              <p className="service-description">50+ Registered Caterers.</p>
              <img src="/small-image-3.jpg" alt="Photography Icon" className="small-image" />
            </div>
          </div>
          <div className="service-box">
            <img src="/event.jpg" alt="Service 4" className="service-image" />
            <div className="service-details">
              <h3 className="service-category">Event Planners</h3>
              <p className="service-description">50+ Registered Event Planners.</p>
              <img src="/small-image-4.jpg" alt="Venue Booking Icon" className="small-image" />
            </div>
          </div>
          <div className="service-box">
            <img src="/music.jpg" alt="Service 5" className="service-image" />
            <div className="service-details">
              <h3 className="service-category">Musicians</h3>
              <p className="service-description">30+ Registered Musicians.</p>
              <img src="/small-image-5.jpg" alt="Music Icon" className="small-image" />
            </div>
          </div>
          <div className="service-box">
            <img src="/dress.jpg" alt="Service 6" className="service-image" />
            <div className="service-details">
              <h3 className="service-category">Wedding Dresses</h3>
              <p className="service-description">15+ Registered Boutiques.</p>
              <img src="/small-image-6.jpg" alt="Transportation Icon" className="small-image" />
            </div>
          </div>
        </div>
      </div>

      {/* New Section for Overlapping Images and Content */}
      <div className="quality-section">
       <div className="quality-content">
          <h2 className="quality-heading">We Keep Quality in Mind</h2>
          <p className="quality-description">
            At our core, we focus on providing the highest quality services for your special events. 
            Our team of professionals ensures every detail is met with precision and excellence. 
            From venue selection to decor, we keep your satisfaction our top priority.
          </p>
          <ul className="quality-list">
            <li>Professional Venues</li>
            <li>Expert Planning</li>
            <li>Customized Decorations</li>
            <li>Personalized Catering</li>
          </ul>
        </div>
        <div className="quality-images">
          <img src="/wed1.jpg" alt="Quality Service 1" className="image-1" />
          <img src="/wed2.jpg" alt="Quality Service 2" className="image-2" />
        </div>
      </div>





    </div>
  );
}
export default Home;