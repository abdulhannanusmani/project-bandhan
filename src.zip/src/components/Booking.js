import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Bookings = () => {
  const [bookings, setBookings] = useState([]);
  const [bids, setBids] = useState([]);

  useEffect(() => {
    // Fetch user bookings
    axios.get('/api/user/bookings').then((response) => {
      setBookings(response.data);
    });

    // Fetch bids made by the user
    axios.get('/api/user/bids').then((response) => {
      setBids(response.data);
    });
  }, []);

  return (
    <div>
      <h2>Your Bookings</h2>
      <ul>
        {bookings.map((booking) => (
          <li key={booking.id}>
            <h3>{booking.venue.name}</h3>
            <p>Booked for: {booking.date}</p>
            <p>Total Amount: {booking.amount}</p>
          </li>
        ))}
      </ul>
      <h2>Your Bids</h2>
      <ul>
        {bids.map((bid) => (
          <li key={bid.id}>
            <h3>Bid for: {bid.venue.name}</h3>
            <p>Bid Price: {bid.price}</p>
            <p>Status: {bid.status}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Bookings;
